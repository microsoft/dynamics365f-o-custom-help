﻿namespace MainProcessor
{
    public interface IProcessLinkParameter
    {
    }
}
