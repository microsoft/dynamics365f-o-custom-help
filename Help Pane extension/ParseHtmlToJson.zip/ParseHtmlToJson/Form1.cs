﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HtmlAgilityPack;
using Newtonsoft.Json;
using System.Globalization;
using System.IO;
namespace ParseHtmlToJson
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string[] allHtml = Directory.GetFiles(htmlFile.Text, "*.htm", SearchOption.AllDirectories);
            if(allHtml.Length == 0)
            {
                allHtml = Directory.GetFiles(htmlFile.Text, "*.html", SearchOption.AllDirectories);
            }
            label3.Enabled = true;
            progressBar1.Enabled = true;
            progressBar1.Visible = true;
            // Set Minimum to 1 to represent the first file being copied.
            progressBar1.Minimum = 1;
            // Set Maximum to the total number of files to copy.
            progressBar1.Maximum = allHtml.Length;
            // Set the initial value of the ProgressBar.
            progressBar1.Value = 1;
            // Set the Step property to a value of 1 to represent each file being copied.
            progressBar1.Step = 1;
            foreach (string file in allHtml)
            {
                int i = 0;
                HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
                htmlDoc.Load(file);

                Newtonsoft.Json.Linq.JObject product = new Newtonsoft.Json.Linq.JObject();
                HtmlNodeCollection nodeMeta = htmlDoc.DocumentNode.SelectNodes("//meta");

                foreach (HtmlNode _htm in nodeMeta)
                {
                    i++;

                    if (i > 2)
                    {
                        HtmlAttributeCollection attribColl = _htm.Attributes;
                        string value = attribColl[1].Value.ToString();
                        string tag = attribColl[0].Value;
                        product.Add(new Newtonsoft.Json.Linq.JProperty(tag, value));
                    }
                }

                HtmlNode node = htmlDoc.DocumentNode.SelectSingleNode("//body");
                product.Add(new Newtonsoft.Json.Linq.JProperty("Content", node.InnerText));
                string jsonFilePath = jsonFile.Text+"\\"+Path.GetFileNameWithoutExtension(file)+".json";

                StreamWriter sysfile = File.CreateText(jsonFilePath);
                using (JsonTextWriter writer = new JsonTextWriter(sysfile))
                {
                    product.WriteTo(writer);
                    progressBar1.PerformStep();
                }
            }
            MessageBox.Show(allHtml.Length + " HTML files converted!");
        }

        private void htmlFile_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
           


            if
             (dialog.ShowDialog() == DialogResult.OK)
            {
                htmlFile.Text = dialog.SelectedPath;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();

            if
             (dialog.ShowDialog() == DialogResult.OK)
            {
                jsonFile.Text = dialog.SelectedPath;
            }
        }
    }

}
