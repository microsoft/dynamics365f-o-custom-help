﻿using System;
using System.Windows.Forms;
using System.IO;
using HtmlAgilityPack;
using System.Web;
using System.Text;
using System.Globalization;

namespace HTML_Locale
{
    public partial class Form1 : Form
    {
        private string locale = string.Empty;
        public Form1()
        {
            InitializeComponent();
            CultureInfo[] cInfo = CultureInfo.GetCultures(CultureTypes.AllCultures);
   
            foreach (CultureInfo culture in cInfo)
            {
                comboLocales.Items.Add(culture);
            }
        }

        private void comboLocales_SelectedIndexChanged(object sender, EventArgs e)
        {
            locale = comboLocales.SelectedItem.ToString().ToLower();
            btnProcess.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //textBoxHTML.Text = Path.Combine(@"D:\Dynamics-365-Operations.es-es\articles\d365F-O");
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            if
             (dialog.ShowDialog() == DialogResult.OK)
            {
                textBoxHTML.Text = dialog.SelectedPath;
            }
            string[] allHtml = Directory.GetFiles(textBoxHTML.Text, "*.html", SearchOption.AllDirectories);
            if(allHtml.Length == 0)
            {
                MessageBox.Show("No HTML file(s) located under this specificed folder - please locate a directory containing HTML files to process!",
                                                "Error Found",
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Exclamation,
                                                MessageBoxDefaultButton.Button1);
            }
            
        }

        private void ProcessAllHTMLFiles(DirectoryInfo dirHTML, string rootFolder)
        {
            foreach (DirectoryInfo d in dirHTML.GetDirectories())
            {
                FileInfo[] dirFiles = d.GetFiles("*.html", SearchOption.AllDirectories);
                if (dirFiles.Length > 0)
                {
                    foreach (FileInfo file in dirFiles)
                    {
                        if (file.Name.ToLower() != "toc.html")
                        {

                            try
                            {
                                HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
                                htmlDoc.Load(file.FullName, Encoding.UTF8);
                                HtmlNodeCollection nodeMeta = htmlDoc.DocumentNode.SelectNodes("//meta");
                                foreach (HtmlNode _htm in nodeMeta)
                                {
                                    HtmlAttributeCollection attribColl = _htm.Attributes;
                                    if (attribColl[0].Value == "ms.locale")
                                    {
                                        attribColl[1].Value = locale;
                                    }
                                }
                                htmlDoc.Save(file.FullName, Encoding.UTF8);
                                progressBar1.PerformStep();
                            }

                            catch (Exception ex)
                            {
                                MessageBox.Show(string.Format("Exception {0}", ex.Message),
                                                "Error Found",
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Exclamation,
                                                MessageBoxDefaultButton.Button1);
                                //Exiting
                                Environment.Exit(-1);
                            }
                           
                        }
                    }
                    ProcessAllHTMLFiles(d, rootFolder);
                 }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            string[] allHtml = Directory.GetFiles(textBoxHTML.Text, "*.html", SearchOption.AllDirectories);
            label3.Enabled = true;
            progressBar1.Enabled = true;
            progressBar1.Visible = true;
            // Set Minimum to 1 to represent the first file being copied.
            progressBar1.Minimum = 0;
            // Set Maximum to the total number of files to copy.
            progressBar1.Maximum = allHtml.Length;
            // Set the initial value of the ProgressBar.
            progressBar1.Value = 1;
            // Set the Step property to a value of 1 to represent each file being copied.
            progressBar1.Step = 1;
            DirectoryInfo dirHTML = new DirectoryInfo(textBoxHTML.Text);
            //Process the files at the root directory
            FileInfo[] rootfiles = dirHTML.GetFiles("*.html", SearchOption.TopDirectoryOnly);
            foreach (FileInfo file in rootfiles)
            {
                if (file.Name.ToLower() != "toc.html")
                {
                    GC.Collect();
                    HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
                    htmlDoc.Load(file.FullName, Encoding.UTF8);
                    HtmlNodeCollection nodeMeta = htmlDoc.DocumentNode.SelectNodes("//meta");
                    foreach (HtmlNode _htm in nodeMeta)
                    {
                        HtmlAttributeCollection attribColl = _htm.Attributes;
                        if (attribColl[0].Value == "ms.locale")
                        {
                            attribColl[1].Value = locale;
                        }
                    }
                    htmlDoc.Save(file.FullName, Encoding.UTF8);
                    progressBar1.PerformStep();
                }
            }
            ProcessAllHTMLFiles(dirHTML, textBoxHTML.Text);
            MessageBox.Show("Processing Complete!", "HTML File Update locale",
                                               MessageBoxButtons.OK,
                                               MessageBoxIcon.Exclamation,
                                               MessageBoxDefaultButton.Button1);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
        
 }
