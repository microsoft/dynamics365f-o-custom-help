﻿using System;
using System.Windows.Forms;
using System.IO;
using HtmlAgilityPack;
using System.Web;
using System.Text;

namespace HTML_Locale
{
    public partial class Form1 : Form
    {
        private string locale = string.Empty;
        public Form1()
        {
            InitializeComponent();
            comboLocales.Items.Add("ar");
            comboLocales.Items.Add("af");
            comboLocales.Items.Add("af-za");
            comboLocales.Items.Add("am");
            comboLocales.Items.Add("am-et");
            comboLocales.Items.Add("ar");
            comboLocales.Items.Add("ar-ae");
            comboLocales.Items.Add("ar-bh");
            comboLocales.Items.Add("ar-dz");
            comboLocales.Items.Add("ar-eg");
            comboLocales.Items.Add("ar-iq");
            comboLocales.Items.Add("ar-jo");
            comboLocales.Items.Add("ar-kw");
            comboLocales.Items.Add("ar-lb");
            comboLocales.Items.Add("ar-ly");
            comboLocales.Items.Add("ar-ma");
            comboLocales.Items.Add("arn");
            comboLocales.Items.Add("arn-cl");
            comboLocales.Items.Add("ar-om");
            comboLocales.Items.Add("ar-qa");
            comboLocales.Items.Add("ar-sa");
            comboLocales.Items.Add("ar-sy");
            comboLocales.Items.Add("ar-tn");
            comboLocales.Items.Add("ar-ye");
            comboLocales.Items.Add("as");
            comboLocales.Items.Add("as-in");
            comboLocales.Items.Add("az");
            comboLocales.Items.Add("az-cyrl");
            comboLocales.Items.Add("az-latn");
            comboLocales.Items.Add("ba");
            comboLocales.Items.Add("ba-ru");
            comboLocales.Items.Add("be");
            comboLocales.Items.Add("be-by");
            comboLocales.Items.Add("bg");
            comboLocales.Items.Add("bg-bg");
            comboLocales.Items.Add("bn");
            comboLocales.Items.Add("bn-bd");
            comboLocales.Items.Add("bn-in");
            comboLocales.Items.Add("bo");
            comboLocales.Items.Add("bo-cn");
            comboLocales.Items.Add("br");
            comboLocales.Items.Add("br-fr");
            comboLocales.Items.Add("bs");
            comboLocales.Items.Add("bs-cyrl");
            comboLocales.Items.Add("bs-latn");
            comboLocales.Items.Add("ca");
            comboLocales.Items.Add("ca-es");
            comboLocales.Items.Add("chr");
            comboLocales.Items.Add("co");
            comboLocales.Items.Add("co-fr");
            comboLocales.Items.Add("cs");
            comboLocales.Items.Add("cs-cz");
            comboLocales.Items.Add("cy");
            comboLocales.Items.Add("cy-gb");
            comboLocales.Items.Add("da");
            comboLocales.Items.Add("da-dk");
            comboLocales.Items.Add("de");
            comboLocales.Items.Add("de-at");
            comboLocales.Items.Add("de-ch");
            comboLocales.Items.Add("de-de");
            comboLocales.Items.Add("de-li");
            comboLocales.Items.Add("de-li");
            comboLocales.Items.Add("de-lu");
            comboLocales.Items.Add("dsb-de");
            comboLocales.Items.Add("dv");
            comboLocales.Items.Add("dv-mv");
            comboLocales.Items.Add("el");
            comboLocales.Items.Add("el-gr");
            comboLocales.Items.Add("en");
            comboLocales.Items.Add("en-029");
            comboLocales.Items.Add("en-au");
            comboLocales.Items.Add("en-bz");
            comboLocales.Items.Add("en-ca");
            comboLocales.Items.Add("en-gb");
            comboLocales.Items.Add("en-hk");
            comboLocales.Items.Add("en-ie");
            comboLocales.Items.Add("en-in");
            comboLocales.Items.Add("en-jm");
            comboLocales.Items.Add("en-my");
            comboLocales.Items.Add("en-nz");
            comboLocales.Items.Add("en-ph");
            comboLocales.Items.Add("en-sg");
            comboLocales.Items.Add("en-tt");
            comboLocales.Items.Add("en-za");
            comboLocales.Items.Add("en-zw");
            comboLocales.Items.Add("es");
            comboLocales.Items.Add("es-419");
            comboLocales.Items.Add("es-ar");
            comboLocales.Items.Add("es-bo");
            comboLocales.Items.Add("es-cl");
            comboLocales.Items.Add("es-co");
            comboLocales.Items.Add("es-cr");
            comboLocales.Items.Add("es-do");
            comboLocales.Items.Add("es-ec");
            comboLocales.Items.Add("es-es");
            comboLocales.Items.Add("es-gt");
            comboLocales.Items.Add("es-hn");
            comboLocales.Items.Add("es-mx");
            comboLocales.Items.Add("es-ni");
            comboLocales.Items.Add("es-pa");
            comboLocales.Items.Add("es-pe");
            comboLocales.Items.Add("es-pr");
            comboLocales.Items.Add("es-py");
            comboLocales.Items.Add("es-sv");
            comboLocales.Items.Add("es-us");
            comboLocales.Items.Add("es-uy");
            comboLocales.Items.Add("es-ve");
            comboLocales.Items.Add("et");
            comboLocales.Items.Add("et-ee");
            comboLocales.Items.Add("eu");
            comboLocales.Items.Add("eu-es");
            comboLocales.Items.Add("fa");
            comboLocales.Items.Add("fa-ir");
            comboLocales.Items.Add("ff");
            comboLocales.Items.Add("ff-latn");
            comboLocales.Items.Add("fi");
            comboLocales.Items.Add("fi-fi");
            comboLocales.Items.Add("fil");
            comboLocales.Items.Add("fil-ph");
            comboLocales.Items.Add("fo");
            comboLocales.Items.Add("fo-fo");
            comboLocales.Items.Add("fr");
            comboLocales.Items.Add("fr-be");
            comboLocales.Items.Add("fr-ca");
            comboLocales.Items.Add("fr-cd");
            comboLocales.Items.Add("fr-ch");
            comboLocales.Items.Add("fr-ci");
            comboLocales.Items.Add("fr-cm");
            comboLocales.Items.Add("fr-fr");
            comboLocales.Items.Add("fr-ht");
            comboLocales.Items.Add("fr-lu");
            comboLocales.Items.Add("fr-ma");
            comboLocales.Items.Add("fr-mc");
            comboLocales.Items.Add("fr-ml");
            comboLocales.Items.Add("fr-re");
            comboLocales.Items.Add("fr-sn");
            comboLocales.Items.Add("fy");
            comboLocales.Items.Add("fy-nl");
            comboLocales.Items.Add("ga");
            comboLocales.Items.Add("ga-ie");
            comboLocales.Items.Add("gd");
            comboLocales.Items.Add("gd-gb");
            comboLocales.Items.Add("gl");
            comboLocales.Items.Add("gl-es");
            comboLocales.Items.Add("gn");
            comboLocales.Items.Add("gn-py");
            comboLocales.Items.Add("gsw");
            comboLocales.Items.Add("gsw-fr");
            comboLocales.Items.Add("gu");
            comboLocales.Items.Add("gu-in");
            comboLocales.Items.Add("ha");
            comboLocales.Items.Add("ha-latn");
            comboLocales.Items.Add("haw");
            comboLocales.Items.Add("haw-us");
            comboLocales.Items.Add("he");
            comboLocales.Items.Add("he-il");
            comboLocales.Items.Add("hi");
            comboLocales.Items.Add("hi-in");
            comboLocales.Items.Add("hr");
            comboLocales.Items.Add("hr-ba");
            comboLocales.Items.Add("hr-hr");
            comboLocales.Items.Add("hsb");
            comboLocales.Items.Add("hsb-de");
            comboLocales.Items.Add("hu");
            comboLocales.Items.Add("hu-hu");
            comboLocales.Items.Add("hy");
            comboLocales.Items.Add("hy-am");
            comboLocales.Items.Add("id");
            comboLocales.Items.Add("id-id");
            comboLocales.Items.Add("ig");
            comboLocales.Items.Add("ig-ng");
            comboLocales.Items.Add("ii");
            comboLocales.Items.Add("ii-cn");
            comboLocales.Items.Add("is");
            comboLocales.Items.Add("is-is");
            comboLocales.Items.Add("it");
            comboLocales.Items.Add("it-ch");
            comboLocales.Items.Add("it-it");
            comboLocales.Items.Add("iu");
            comboLocales.Items.Add("iu-cans");
            comboLocales.Items.Add("iu-latn");
            comboLocales.Items.Add("ja");
            comboLocales.Items.Add("ja-jp");
            comboLocales.Items.Add("jv");
            comboLocales.Items.Add("jv-latn");
            comboLocales.Items.Add("ka");
            comboLocales.Items.Add("ka-ge");
            comboLocales.Items.Add("kk");
            comboLocales.Items.Add("kk-kz");
            comboLocales.Items.Add("kl");
            comboLocales.Items.Add("kl-gl");
            comboLocales.Items.Add("km");
            comboLocales.Items.Add("km-kh");
            comboLocales.Items.Add("kn");
            comboLocales.Items.Add("kn-in");
            comboLocales.Items.Add("ko");
            comboLocales.Items.Add("kok");
            comboLocales.Items.Add("kok-in");
            comboLocales.Items.Add("ko-kr");
            comboLocales.Items.Add("ku");
            comboLocales.Items.Add("ku-arab");
            comboLocales.Items.Add("ky");
            comboLocales.Items.Add("ky-kg");
            comboLocales.Items.Add("lb");
            comboLocales.Items.Add("lb-lu");
            comboLocales.Items.Add("lo");
            comboLocales.Items.Add("lo-la");
            comboLocales.Items.Add("lt");
            comboLocales.Items.Add("lt-lt");
            comboLocales.Items.Add("lv");
            comboLocales.Items.Add("lv-lv");
            comboLocales.Items.Add("mg");
            comboLocales.Items.Add("mg-mg");
            comboLocales.Items.Add("mi");
            comboLocales.Items.Add("mi-nz");
            comboLocales.Items.Add("mk");
            comboLocales.Items.Add("mk-mk");
            comboLocales.Items.Add("ml");
            comboLocales.Items.Add("ml-in");
            comboLocales.Items.Add("mn");
            comboLocales.Items.Add("mn-cyrl");
            comboLocales.Items.Add("mn-mn");
            comboLocales.Items.Add("mn-mong");
            comboLocales.Items.Add("moh");
            comboLocales.Items.Add("moh-ca");
            comboLocales.Items.Add("mr");
            comboLocales.Items.Add("mr-in");
            comboLocales.Items.Add("ms");
            comboLocales.Items.Add("ms-bn");
            comboLocales.Items.Add("ms-my");
            comboLocales.Items.Add("mt");
            comboLocales.Items.Add("mt-mt");
            comboLocales.Items.Add("my");
            comboLocales.Items.Add("my-mm");
            comboLocales.Items.Add("nb");
            comboLocales.Items.Add("nb-no");
            comboLocales.Items.Add("ne");
            comboLocales.Items.Add("ne-in");
            comboLocales.Items.Add("ne-np");
            comboLocales.Items.Add("nl");
            comboLocales.Items.Add("nl-be");
            comboLocales.Items.Add("nl-nl");
            comboLocales.Items.Add("nn");
            comboLocales.Items.Add("nn-no");
            comboLocales.Items.Add("no");
            comboLocales.Items.Add("nqo");
            comboLocales.Items.Add("nqo-gn");
            comboLocales.Items.Add("nso");
            comboLocales.Items.Add("nso-za");
            comboLocales.Items.Add("oc");
            comboLocales.Items.Add("oc-fr");
            comboLocales.Items.Add("om");
            comboLocales.Items.Add("om-et");
            comboLocales.Items.Add("or");
            comboLocales.Items.Add("or-in");
            comboLocales.Items.Add("pa");
            comboLocales.Items.Add("pa-arab");
            comboLocales.Items.Add("pa-in");
            comboLocales.Items.Add("pl");
            comboLocales.Items.Add("pl-pl");
            comboLocales.Items.Add("prs");
            comboLocales.Items.Add("prs-af");
            comboLocales.Items.Add("pa");
            comboLocales.Items.Add("ps");
            comboLocales.Items.Add("ps-af");
            comboLocales.Items.Add("pt");
            comboLocales.Items.Add("pt-ao");
            comboLocales.Items.Add("pt-br");
            comboLocales.Items.Add("pt-pt");
            comboLocales.Items.Add("qut");
            comboLocales.Items.Add("qut-gt");
            comboLocales.Items.Add("quz");
            comboLocales.Items.Add("quz-bo");
            comboLocales.Items.Add("quz-ec");
            comboLocales.Items.Add("quz-pe");
            comboLocales.Items.Add("rm");
            comboLocales.Items.Add("rm-ch");
            comboLocales.Items.Add("ro");
            comboLocales.Items.Add("ro-md");
            comboLocales.Items.Add("ro-ro");
            comboLocales.Items.Add("ru");
            comboLocales.Items.Add("ru-ru");
            comboLocales.Items.Add("rw");
            comboLocales.Items.Add("rw-rw");
            comboLocales.Items.Add("sa");
            comboLocales.Items.Add("sah");
            comboLocales.Items.Add("sah-ru");
            comboLocales.Items.Add("sa-in");
            comboLocales.Items.Add("sd");
            comboLocales.Items.Add("sd-arab");
            comboLocales.Items.Add("se");
            comboLocales.Items.Add("se-fi");
            comboLocales.Items.Add("se-no");
            comboLocales.Items.Add("se-se");
            comboLocales.Items.Add("si");
            comboLocales.Items.Add("si-lk");
            comboLocales.Items.Add("sk");
            comboLocales.Items.Add("sk-sk");
            comboLocales.Items.Add("sl");
            comboLocales.Items.Add("sl-si");
            comboLocales.Items.Add("sma");
            comboLocales.Items.Add("sma-no");
            comboLocales.Items.Add("sma-se");
            comboLocales.Items.Add("smj");
            comboLocales.Items.Add("smj-no");
            comboLocales.Items.Add("smj-se");
            comboLocales.Items.Add("smn");
            comboLocales.Items.Add("smn-fi");
            comboLocales.Items.Add("sms");
            comboLocales.Items.Add("sms-fi");
            comboLocales.Items.Add("sn");
            comboLocales.Items.Add("sn-latn");
            comboLocales.Items.Add("so");
            comboLocales.Items.Add("so-so");
            comboLocales.Items.Add("sq");
            comboLocales.Items.Add("sq-al");
            comboLocales.Items.Add("sr");
            comboLocales.Items.Add("sr-cyrl");
            comboLocales.Items.Add("sr-latn");
            comboLocales.Items.Add("st");
            comboLocales.Items.Add("st-za");
            comboLocales.Items.Add("sv");
            comboLocales.Items.Add("sv-fi");
            comboLocales.Items.Add("sv-se");
            comboLocales.Items.Add("sw");
            comboLocales.Items.Add("sw-ke");
            comboLocales.Items.Add("syr");
            comboLocales.Items.Add("syr-sy");
            comboLocales.Items.Add("ta");
            comboLocales.Items.Add("ta-in");
            comboLocales.Items.Add("ta-lk");
            comboLocales.Items.Add("te");
            comboLocales.Items.Add("te-in");
            comboLocales.Items.Add("tg");
            comboLocales.Items.Add("tg-cyrl");
            comboLocales.Items.Add("th");
            comboLocales.Items.Add("th-th");
            comboLocales.Items.Add("ti");
            comboLocales.Items.Add("ti-er");
            comboLocales.Items.Add("ti-et");
            comboLocales.Items.Add("tk");
            comboLocales.Items.Add("tk-tm");
            comboLocales.Items.Add("tn");
            comboLocales.Items.Add("tn-bw");
            comboLocales.Items.Add("tn-za");
            comboLocales.Items.Add("tr");
            comboLocales.Items.Add("tr-tr");
            comboLocales.Items.Add("ts");
            comboLocales.Items.Add("ts-za");
            comboLocales.Items.Add("tt");
            comboLocales.Items.Add("tt-ru");
            comboLocales.Items.Add("tzm");
            comboLocales.Items.Add("ug");
            comboLocales.Items.Add("ug-cn");
            comboLocales.Items.Add("uk");
            comboLocales.Items.Add("uk-ua");
            comboLocales.Items.Add("ur");
            comboLocales.Items.Add("ur-in");
            comboLocales.Items.Add("ur-pk");
            comboLocales.Items.Add("uz");
            comboLocales.Items.Add("uz-cyrl");
            comboLocales.Items.Add("uz-latn");
            comboLocales.Items.Add("vi");
            comboLocales.Items.Add("vi-vn");
            comboLocales.Items.Add("wo-sn");
            comboLocales.Items.Add("xh");
            comboLocales.Items.Add("xh-za");
            comboLocales.Items.Add("yo");
            comboLocales.Items.Add("yo-ng");
            comboLocales.Items.Add("zgh");
            comboLocales.Items.Add("zh");
            comboLocales.Items.Add("zh-chs");
            comboLocales.Items.Add("zh-cht");
            comboLocales.Items.Add("zh-cn");
            comboLocales.Items.Add("zh-hans");
            comboLocales.Items.Add("zh-hant");
            comboLocales.Items.Add("zh-hk");
            comboLocales.Items.Add("zh-mo");
            comboLocales.Items.Add("zh-sg");
            comboLocales.Items.Add("zh-tw");
            comboLocales.Items.Add("zu");
            comboLocales.Items.Add("zu-za");
        }

        private void comboLocales_SelectedIndexChanged(object sender, EventArgs e)
        {
            locale = comboLocales.SelectedItem.ToString();
            btnProcess.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //textBoxHTML.Text = Path.Combine(@"D:\Dynamics-365-Operations.es-es\articles\d365F-O");
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            if
             (dialog.ShowDialog() == DialogResult.OK)
            {
                textBoxHTML.Text = dialog.SelectedPath;
            }
        }

        private void ProcessAllHTMLFiles(DirectoryInfo dirHTML, string rootFolder)
        {
            foreach (DirectoryInfo d in dirHTML.GetDirectories())
            {
                FileInfo[] dirFiles = d.GetFiles("*.html", SearchOption.AllDirectories);
                if (dirFiles.Length > 0)
                {
                    foreach (FileInfo file in dirFiles)
                    {
                        if (file.Name.ToLower() != "toc.html")
                        {

                            try
                            {
                                HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
                                htmlDoc.Load(file.FullName, Encoding.UTF8);
                                HtmlNodeCollection nodeMeta = htmlDoc.DocumentNode.SelectNodes("//meta");
                                foreach (HtmlNode _htm in nodeMeta)
                                {
                                    HtmlAttributeCollection attribColl = _htm.Attributes;
                                    if (attribColl[0].Value == "ms.locale")
                                    {
                                        attribColl[1].Value = locale;
                                    }
                                }
                                htmlDoc.Save(file.FullName, Encoding.UTF8);
                                progressBar1.PerformStep();
                            }

                            catch (Exception ex)
                            {
                                MessageBox.Show(string.Format("Exception {0}", ex.Message),
                                                "Error Found",
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Exclamation,
                                                MessageBoxDefaultButton.Button1);
                                //Exiting
                                Environment.Exit(-1);
                            }
                           
                        }
                    }
                    ProcessAllHTMLFiles(d, rootFolder);
                 }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            string[] allHtml = Directory.GetFiles(textBoxHTML.Text, "*.html", SearchOption.AllDirectories);
            label3.Enabled = true;
            progressBar1.Enabled = true;
            progressBar1.Visible = true;
            // Set Minimum to 1 to represent the first file being copied.
            progressBar1.Minimum = 0;
            // Set Maximum to the total number of files to copy.
            progressBar1.Maximum = allHtml.Length;
            // Set the initial value of the ProgressBar.
            progressBar1.Value = 1;
            // Set the Step property to a value of 1 to represent each file being copied.
            progressBar1.Step = 1;
            DirectoryInfo dirHTML = new DirectoryInfo(textBoxHTML.Text);
            //Process the files at the root directory
            FileInfo[] rootfiles = dirHTML.GetFiles("*.html", SearchOption.TopDirectoryOnly);
            foreach (FileInfo file in rootfiles)
            {
                if (file.Name.ToLower() != "toc.html")
                {
                    GC.Collect();
                    HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
                    htmlDoc.Load(file.FullName, Encoding.UTF8);
                    HtmlNodeCollection nodeMeta = htmlDoc.DocumentNode.SelectNodes("//meta");
                    foreach (HtmlNode _htm in nodeMeta)
                    {
                        HtmlAttributeCollection attribColl = _htm.Attributes;
                        if (attribColl[0].Value == "ms.locale")
                        {
                            attribColl[1].Value = locale;
                        }
                    }
                    htmlDoc.Save(file.FullName, Encoding.UTF8);
                    progressBar1.PerformStep();
                }
            }
            ProcessAllHTMLFiles(dirHTML, textBoxHTML.Text);
            MessageBox.Show("Processing Complete!", "HTML File Update locale",
                                               MessageBoxButtons.OK,
                                               MessageBoxIcon.Exclamation,
                                               MessageBoxDefaultButton.Button1);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
        
 }
